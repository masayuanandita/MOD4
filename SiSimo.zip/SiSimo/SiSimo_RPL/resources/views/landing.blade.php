<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>@yield('title')</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="{{ URL::asset('css/styles.css'); }}" rel="stylesheet" />
    </head>
    <style>
        body {
            background-image: url('https://i1.wp.com/gantdaily.com/wp-content/uploads/2020/09/CustomProductsCorporationCPCSigns-seotool-55250-ReviewCommonTraffic-image1.jpg?fit=1500%2C900&ssl=1')
        }
    </style>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container px-4 px-lg-5">
                <h1 style="color: white">Sisimo</h1>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4"></ul>
                    <ul class="navbar-nav mb-2 mb-lg-0 ms-lg-4">
                        <div class="text-end"><a class="btn btn-outline-light mt-auto me-1" href="{{ url('login') }}">Sign In</a></div>
                        <div class="text-end"><a class="btn btn-outline-light mt-auto" href="{{ url('register') }}">Register</a></div>
                    </ul>
                </div>
            </div>
        </nav>

        <header style="margin: 150px">
            <h1>Selamat Datang di web</h1>
            <h1>pelayanan SIM online</h1>
        </header>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
