<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ktp extends Model
{
    use HasFactory;
    protected $table = 'ktps';

    /**
     * The attributes that are mass assignable
     * 
     * @var array<int, string>
     */

    protected $fillable = [
        'nik',
        'nama_pengguna',
        'tempat_lahir',
        'tanggal_lahir',
        'jenis_kelamin',
        'alamat',
        'golongan_darah',
        'masa_berlaku',
    ];

    public function userKTP(){
        return $this->belongsTo(KTPUser::class, 'nik');
    }
}
