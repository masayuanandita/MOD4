<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sim extends Model
{
    use HasFactory;
    protected $guarded=[];
    protected $table = 'sims';

    /**
     * The attributes that are mass assignable
     * 
     * @var array<int, string>
     */

    protected $fillable = [
        'nik',
        'nama_pengguna',
        'tanggal_lahir',
        'jenis_kelamin',
        'alamat',
        'golongan_darah',
        'masa_berlaku',
        'lokasi',
        'jenis_sim',
        'Lokasi',
        'pekerjaan',
        'tanggal_ambil',
    ];

    public function userKTP(){
        return $this->belongsTo(KTPUser::class, 'nik');
    }

    public function sims(){
        return $this->belongsTo(Pembuatan_SIM::class, 'nik', 'id');
    }
}
