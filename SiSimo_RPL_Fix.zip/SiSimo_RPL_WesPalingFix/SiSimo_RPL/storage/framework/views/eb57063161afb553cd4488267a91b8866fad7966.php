<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

  <title>Pengambilan SIM</title>
</head>
<style>
    body {
        background-image: url('https://i1.wp.com/gantdaily.com/wp-content/uploads/2020/09/CustomProductsCorporationCPCSigns-seotool-55250-ReviewCommonTraffic-image1.jpg?fit=1500%2C900&ssl=1')
    }
</style>
<body>
  <div class="container">
    <div class="row justify-content-md-center"
    style="width: 700px; background-color: white; margin-top: 25px; margin-left: 200px; border-radius: 25px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)">
      <div class="col-md-8">
        <h1 class="text-center text-warning" style="margin-top: 60px; margin-bottom: 60px;">Pengambilan SIM</h1>
        <form  action="<?php echo e(url('pengambilanAction')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="inputNama">Nama</label>
            <input type="text" class="form-control" name="nama_pengguna" id="inputNama" placeholder="Masukan Nama Anda">
          </div>
          <div class="form-group">
            <label for="inputNIK">NIK</label>
            <input type="text" class="form-control" name="nik" id="inputNIK" placeholder="Masukan NIK Anda">
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="inputJenisSIM">Jenis SIM</label>
              <input type="text" class="form-control" name="jenis_sim" id="inputJenisSIM" placeholder="Pilih Jenis SIM">
            </div>
            <div class="form-group col-md-6">
              <label for="inputTanggalAmbil">Tanggal Pengambilan</label>
              <input type="date" class="form-control" name="tanggal_pengambilan" id="inputTanggalAmbil" placeholder="Masukan Tanggal">
            </div>
          </div>
          <button type="submit" class="btn btn-warning" style="margin-bottom: 60px;">Lanjutkan</button>
        </form>
      </div>
    </div>
  </div>



  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
  </script>
</body>

</html>
<?php /**PATH E:\Informatika\Semester 6\RPL Desain dan Implementasi\SiSimo_RPL_WesFixMbohMumet\SiSimo_RPL\resources\views/pengambilan.blade.php ENDPATH**/ ?>