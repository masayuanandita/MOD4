<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class hasil_ujian extends Model
{
    use HasFactory;
    protected $table = 'hasil_ujians';
    /**
     * The attributes that are mass assignable
     * 
     * @var array<int, string>
     */

    protected $fillable = [
        'ujian_tulis',
        'ujian_praktek',
        'hasil_kelulusan',
    ];

    public function User(){
        return $this->belongsTo(users::class, 'id');
    }

    public function hasil_ujian(){
        return $this->belongsTo(HasilUjian::class, 'id');
    }
}
