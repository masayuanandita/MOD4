<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class jadwal extends Model
{
    use HasFactory;
    protected $table = 'jadwals';

    /**
     * The attributes that are mass assignable
     * 
     * @var array<int, string>
     */

    protected $fillable = [
        'hari',
        'tanggal',
        'jam',
        'lokasi',
    ];

    public function IDJadwal(){
        return $this->belongsTo(Jadwal_ID::class, 'id');
    }
}
