<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pengambilan extends Model
{
    use HasFactory;
    protected $guarded=[];
    protected $table = 'pengambilans';

    /**
     * The attributes that are mass assignable
     * 
     * @var array<int, string>
     */

    protected $fillable = [
        'nik',
        'nama_pengguna',
        'jenis_sim',
        'tanggal_pengambilan',
    ];
}
