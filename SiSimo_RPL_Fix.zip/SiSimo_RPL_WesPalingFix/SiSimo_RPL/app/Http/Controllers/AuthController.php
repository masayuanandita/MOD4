<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Sim;
use App\Models\perpanjangan;
use App\Models\pengambilan;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function login(){
        return view('login');
    }
    public function register(){
        return view('register');
    }
    public function loginAction(Request $req){
        $user = User::where('nik', $req->nik)->first();

        if($user){
            return view('home');
        }

        return view('landing'); 
    }
    public function registerAction(Request $req){
        $user = User::create([
            'name' => $req->name,
            'email' => $req->email,
            'nik' => $req->nik,
            'password' => $req->password,
          ]);
      return view('home');
    }

    public function home(){
        return view('home');
    }

    public function pendaftaran(){
        return view('pendaftaran');
    }
    public function perpanjangan(){
        return view('perpanjangan');
    }
    public function pengambilan(){
        return view('pengambilan');
    }

    public function pendaftaranAction(Request $req){
        $sim = Sim::create([
            'nik' => $req->nik,
            'nama_pengguna' => $req->nama_pengguna,
            'tanggal_lahir' => $req->tanggal_lahir,
            'alamat' => $req->alamat,
            'tempat_lahir' => $req->tempat_lahir,
            'lokasi' => $req->lokasi,
            'jenis_sim' => $req->jenis_sim,
            'pekerjaan' => $req->pekerjaan,
            'tanggal_ujian' => $req->tanggal_ujian,
        ]);
        return view('landing');
    }

    public function perpanjanganAction(Request $req){
        $perpanjangan = perpanjangan::create([
            'nik' => $req->nik,
            'nama_pengguna' => $req->nama_pengguna,
            'alamat' => $req->alamat,
            'jenis_sim' => $req->jenis_sim,
            'sim_lama' => $req->sim_lama,
        ]);
        return view('landing');
    }
    public function pengambilanAction(Request $req){
        $pengambilan = pengambilan::create([
            'nama_pengguna' => $req->nama_pengguna,
            'nik' => $req->nik,
            'jenis_sim' => $req->jenis_sim,
            'tanggal_pengambilan' => $req->tanggal_pengambilan,
        ]);
        return view('landing');
    }

}
