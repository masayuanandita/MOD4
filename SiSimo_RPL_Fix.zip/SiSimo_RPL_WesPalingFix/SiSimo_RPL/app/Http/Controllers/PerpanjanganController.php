<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PerpanjanganController extends Controller
{
    //
}
