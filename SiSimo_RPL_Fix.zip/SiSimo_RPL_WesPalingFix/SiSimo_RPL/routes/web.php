<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HasilUjianController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\KtpController;
use App\Http\Controllers\SimController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('landing');
});
Route::get('login', [AuthController::class, 'login']);
Route::get('register', [AuthController::class, 'register']);
Route::post('loginAction', [AuthController::class, 'loginAction']);
Route::post('registerAction', [AuthController::class, 'registerAction']);
Route::get('index_output', [AuthController::class, 'index_output']);
Route::get('home', [AuthController::class, 'home']);
Route::get('pendaftaran', [AuthController::class, 'pendaftaran']);
Route::get('pengambilan', [AuthController::class, 'pengambilan']);
Route::get('perpanjangan', [AuthController::class, 'perpanjangan']);
Route::post('pendaftaranAction', [AuthController::class, 'pendaftaranAction']);
Route::post('pengambilanAction', [AuthController::class, 'pengambilanAction']);
Route::post('perpanjanganAction', [AuthController::class, 'perpanjanganAction']);