<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HasilUjianController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\KtpController;
use App\Http\Controllers\SimController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('landing');
});
Route::get('login', [AuthController::class, 'login']);
Route::get('registrasi', [AuthController::class, 'registrasi']);
Route::get('index_output', [AuthController::class, 'index_output']);
